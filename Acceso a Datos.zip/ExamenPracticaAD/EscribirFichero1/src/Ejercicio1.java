import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class Ejercicio1 {
    public static void writeSeriesToFile(List<String> nombres, String nombreArchivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
            for (String nombre : nombres) {
                writer.write(nombre);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) throws Exception {
        List<String> nombres = new ArrayList<>();
        nombres.add("Stranger Things");
        nombres.add("Outer Banks");
        nombres.add("On Tree Hill");
        String nombreArchivo = "series.txt";
        writeSeriesToFile(nombres, nombreArchivo);

        System.out.println("Nombres de series escritos en " + nombreArchivo);
        
    }
}
