import java.io.Serializable;
import java.util.List;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class Alumno implements Serializable {
    private String nombre;
    private int edad;
    private String curso;

    public Alumno(String nombre, int edad, String curso) {
        this.nombre = nombre;
        this.edad = edad;
        this.curso = curso;
    }

    public String getNombre() {
        return nombre;
    }


    public int getEdad() {
        return edad;
    }

    public String getCurso() {
        return curso;
    }

    //Método llamado escribirAlumnosEnArchivo
    public static void escribirAlumnosEnArchivo(List<Alumno> listaAlumnos, String nombreArchivo) throws IOException {
        try (ObjectOutputStream OOS = new ObjectOutputStream(new FileOutputStream(nombreArchivo))) {
            for (Alumno alumno : listaAlumnos) {
                OOS.writeObject(alumno);
                System.out.println("Archivo: " + nombreArchivo + " escrito correctamente");
            }
        }catch (IOException e) {
            throw new IOException("Error al escribir en el archivo: " + e.getMessage()); 
        }
    }
}
