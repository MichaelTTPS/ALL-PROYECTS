import java.util.ArrayList;
import java.util.List;
import java.io.IOException;

public class mainAlumnos  {
    public static void main(String[] args) {
// Crear una lista de alumnos
List<Alumno> listaAlumnos = new ArrayList<>();
// Añade 3 alumnos a la lista
listaAlumnos.add(new Alumno("Pedro", 21, "DAM2"));
listaAlumnos.add(new Alumno("Laura", 23, "DAM2"));
listaAlumnos.add(new Alumno("Marta", 20, "DAM2"));

// Llama al método escribir
try {
    Alumno.escribirAlumnosEnArchivo(listaAlumnos, "alumnos.dat");
    System.out.println("Alumnos escritos en el archivo correctamente.");
} catch (IOException e) {
    System.err.println("Error al escribir los alumnos en el archivo: " + e.getMessage());
}
}
}
