import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class App {

    // URL de la base de datos, usuario y contraseña
    static final String DB_URL = "jdbc:mysql://localhost:3306/Escuela";
    static final String USER = "root";
    static final String PASS = "1234pepito@"; 

        /*Método en Java que inserte un nuevo alumno en la tabla con tus datos y
        muestre por pantalla el número de filas afectadas. */
        public void insertarAlumnos(String nombre, int edad, String email) {
            String sql = "INSERT INTO Alumnos (nombre, edad, email) VALUES (?,?,?)";

            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, nombre);
                pstmt.setInt(2, edad);
                pstmt.setString(3, email);

                int filasAfectadas = pstmt.executeUpdate();
                System.out.println("Alumno insertado correctamente. Filas afectadas: " + filasAfectadas);

            } catch (SQLException e) {
                System.out.println("Error al insertar el alumno: " + e.getMessage());
                e.printStackTrace();
            }
        }

        /*Método en Java que muestra todos los alumnos almacenados en la base de
        datos y muestre el nombre y edad de cada alumno en consola. */
        public void mostrarTodosLosAlumnos() {
        String sql = "SELECT nombre, edad FROM Alumnos";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

                System.out.println("Lista de Alumnos:");
            while (rs.next()) {
                String nombre = rs.getString("nombre");
                int edad = rs.getInt("edad");
                System.out.println("Nombre: " + nombre + ", Edad: " + edad);
            }
        } catch (SQLException e) {
            System.out.println("Error al mostrar los alumnos: " + e.getMessage());
            e.printStackTrace();
        }
}
        /*Método en Java que actualice la edad de un alumno dado su ID, modifica el
        que quieras para probar el método. */
        public void actualizarEdad(int id, int nuevaEdad) {
            String sql = "UPDATE Alumnos SET edad = ? WHERE id = ?";
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setInt(1, nuevaEdad);
                pstmt.setInt(2, id);
                int filasAfectadas = pstmt.executeUpdate();

                if (filasAfectadas > 0) {
                    System.out.println("Edad actualizada correctamente. Filas afectadas: " + filasAfectadas);
                } else {
                    System.out.println("No se encontró el alumno con ID: " + id);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
}
       
    public static void main(String[] args) throws Exception {
        App app = new App();
        // Insertar un nuevo alumno
        app.insertarAlumnos("Juan Perez", 20, "juan@gmail.com");
        // Mostrar todos los alumnos
        app.mostrarTodosLosAlumnos();
        // Actualizar la edad de un alumno con ID 1
        app.actualizarEdad(1, 21);

        // mostrar todos los alumnos nuevamente para ver el cambio
        app.mostrarTodosLosAlumnos();
        
    }
}
