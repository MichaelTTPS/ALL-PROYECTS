import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class superheroesLectura {
    
    public static void leerSuperheroesDesdeXML(String rutaArchivo) {
        try {
            File archivo = new File("superheroes.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document documento = builder.parse(archivo);
            documento.getDocumentElement().normalize();

            System.out.println("Root element :" + documento.getDocumentElement().getNodeName());
            NodeList listaSuperheroes = documento.getElementsByTagName("superheroe");

            for (int i = 0; i < listaSuperheroes.getLength(); i++) {
                Node nodo = listaSuperheroes.item(i);
                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                    Element elemento = (Element) nodo;
                  
                    String nombre = elemento.getElementsByTagName("nombre").item(0).getTextContent();
                    System.out.println("Nombre del superhéroe: " + nombre);
                }
            }
            
        System.out.println("Lectura de superhéroes finalizada.");

        } catch (Exception e) {
            System.out.println("Error al leer el archivo XML: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
