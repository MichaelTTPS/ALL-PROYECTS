public class Superheroes3 {
    public static void main(String[] args) throws Exception {

        superheroesLectura.leerSuperheroesDesdeXML("superheroes.xml");
    
    }
}


