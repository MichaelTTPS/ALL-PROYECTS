import java.io.*;
public class Persona implements Serializable {

private String id;
private String nombre;
private int edad;
private String dni;

// Getters y Setters
public String getId() {
    return id;
}

public void setId(String id) {
    this.id = id;
}

public String getNombre() {
    return nombre;
}

public void setNombre(String nombre) {
    this.nombre = nombre;
}

public int getEdad() {
    return edad;
}

public void setEdad(int edad) {
    this.edad = edad;
}

public String getDni() {
    return dni;
}

public void setDni(String dni) {
    this.dni = dni;
}

    // Metodo toString
    @Override
    public String toString() {
        return "Persona: [id='" + id + ", nombre=" + nombre  + ", edad=" + edad + ", dni=" + dni + "]";
    }

    // Método para guardar un objeto de tipo Persona en un fichero
    public static void guardarObjeto(Persona persona, String filename) {
    try (ObjectOutputStream ObjPersona = new ObjectOutputStream(new FileOutputStream(filename))) {
        ObjPersona.writeObject(persona);
    } catch (IOException e) {
        System.out.println("\nError al guardar el objeto: " + e.getMessage());
    }
}

// Método para recuperar un objeto de tipo Persona de un fichero
public static Persona recuperarObjeto(String filename) {
    Persona persona = null;
    try (ObjectInputStream RObjPersona = new ObjectInputStream(new FileInputStream(filename))) {
        persona = (Persona) RObjPersona.readObject();
    } catch (IOException | ClassNotFoundException e) {
        System.out.println("Error al recuperar el objeto: " + e.getMessage());
    }
    return persona;
}

    public static void main(String[] args) throws Exception {
        //1.a. Crea una función para guardar un objeto Persona en un fichero con el nombre persona1
        Persona persona1 = new Persona();
        
        // Creamos el objeto Persona
        persona1.setId("101");
        persona1.setNombre("Pepito");
        persona1.setEdad(25);
        persona1.setDni("12345678A");

        //Guardamos el objeto Persona en un fichero
        guardarObjeto(persona1, "persona1.txt");

        // 1.b. Crea una función para recuperar un objeto Persona del fichero persona1
        // Recuperamos el objeto Persona del fichero
        Persona personaRecuperada = recuperarObjeto("persona1.txt");
        System.out.println("Persona recuperada:");
        System.out.println("ID: " + personaRecuperada.getId());
        System.out.println("Nombre: " + personaRecuperada.getNombre());
        System.out.println("Edad: " + personaRecuperada.getEdad());
        System.out.println("DNI: " + personaRecuperada.getDni());

        System.out.println("-------------------------");

        // 1.c. Modifica sus propiedades y vuelve a guardarlo en el fichero persona1
        personaRecuperada.setId("112");
        personaRecuperada.setNombre("Pepita");
        personaRecuperada.setEdad(24);
        guardarObjeto(personaRecuperada, "persona1.txt");

        // Recuperamos de nuevo el objeto Persona del fichero para ver los cambios
        Persona personaModificada = recuperarObjeto("persona1.txt");
        System.out.println("Persona modificada:");
        System.out.println("ID: " + personaModificada.getId());
        System.out.println("Nombre: " + personaModificada.getNombre());
        System.out.println("Edad: " + personaModificada.getEdad());
        System.out.println("DNI: " + personaModificada.getDni());

        System.out.println("-------------------------");

        // 2.a. Crear un fichero de texto utilizando FileWriter
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("persona2.txt"))) {
            writer.write("Esto es una línea de texto en el fichero creado con FileWriter.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el fichero: " + e.getMessage());
        }

        // 2.b. Lee el fichero de texto utilizando FileReader y muestra su contenido por pantalla
        try (BufferedReader reader = new BufferedReader(new FileReader("persona2.txt"))) {
            String linea;
            System.out.println("Contenido del fichero:");
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (IOException e) {
            System.out.println("Error al leer el fichero: " + e.getMessage());
        }

        System.out.println("-------------------------");

        /*  3.a Lee un fichero de tipo imagen (binario), p.e: crondose.jpg puede ser cualquiera, y muestra su contenido por pantalla
        try (FileInputStream fis = new FileInputStream("gato2.jpg")) {
            byte[] buffer = new byte[1200]; // Buffer de 1200 bytes para leer el fichero en partes
            int bytesRead;
            System.out.println("Contenido del fichero de imagen:");
            while ((bytesRead = fis.read(buffer)) != -1) {
                for (int i = 0; i < bytesRead; i++) {
                    System.out.print((char) buffer[i]);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el fichero de imagen: " + e.getMessage());
        } */

    }
}

