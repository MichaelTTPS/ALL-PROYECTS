import java.io.File;

public class RutaEjemplo2 {
public static void main(String[] args) {
File archivo = new File(".\\reporte.txt");

    // Verificar si el archivo existe
    if (archivo.exists()) {
        System.out.println("\nEl archivo existe.\n");
    } else {
        System.out.println("\nEl archivo no existe.");
    }

    // Verificar permisos
    System.out.println("Se puede leer: " + archivo.canRead());
    System.out.println("Se puede escribir: " + archivo.canWrite());
    System.out.println("Se puede ejecutar: " + archivo.canExecute());

    System.out.println();

    // Modificar permisos (ejemplo: quitar permisos de escritura)
    archivo.setReadable(true);
    archivo.setWritable(false);
    archivo.setExecutable(true);

}
}