import java.io.File;
import java.io.IOException;

public class PermisosFicheros {
public static void main(String[] args) {
File archivo = new File(".\\PermisosFicheros.txt");

    // Verificar si el archivo existe
    if (archivo.exists()) {
        System.out.println("\nEl archivo existe.\n");
    } else {
        System.out.println("\nEl archivo no existe.");
        try {
            System.out.println("Archivo creado: " + archivo.createNewFile());
        } catch (IOException e) {
            
        }
    }

    // Mostrar información del archivo
    if (archivo.exists()) {
        System.out.println("Nombre del archivo: " + archivo.getName());
        System.out.println("¿Es un directorio? " + archivo.isDirectory());
        System.out.println("¿Es un archivo? " + archivo.isFile());
        System.out.println("Ruta: " + archivo.getPath());
        System.out.println("Ruta absoluta: " + archivo.getAbsolutePath());
        System.out.println("Se puede escribir: " + archivo.canRead());
        System.out.println("Se puede leer: " + archivo.canWrite());
        System.out.println("Se puede ejecutar: " + archivo.canExecute());

        // listar archivos en el directorio padre
        int numArchivos = archivo.getParentFile().listFiles().length;
        if(numArchivos > 1) {
            System.out.println("El directorio padre tiene " + numArchivos + " archivos.\n");
        } else {
            System.out.println("El directorio padre tiene " + numArchivos + " archivo.\n");
        }

        
        // crear un directorio si el archivo no es un directorio y no existe
        if(!archivo.isDirectory()) {
            File nuevoDirectorio = new File(".\\NuevoDirectorio");
            if(!nuevoDirectorio.exists()) {
                System.out.println("Directorio creado: " + nuevoDirectorio.mkdir() + "\n");
            }

        // crear un archivo dentro del nuevo directorio
        File nuevoArchivo = new File(nuevoDirectorio, "NuevoArchivo.txt");
        try {
            System.out.println("Archivo creado: " + nuevoArchivo.createNewFile());
        } catch (IOException e) {
            System.err.println("Error al crear el archivo: " + e.getMessage());
        }
        }

}
}
}