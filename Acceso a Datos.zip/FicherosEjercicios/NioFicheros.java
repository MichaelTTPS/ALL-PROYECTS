
import java.io.IOException;
import java.nio.file.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NioFicheros {
    public static void main(String[] args) {

        // Listar los archivos en el directorio actual
    Path path = Path.of(".\\");


        System.out.println("\nTotal archivos en el directorio actual: \n");

    try (Stream<Path> files = Files.list(path)) {

            for (Path path1 : files.collect(Collectors.toList())) {
                System.out.println(path1);
            }

    } catch (IOException e) {
        System.err.println("Error al leer: " + path.getFileName());
    }

}
}
