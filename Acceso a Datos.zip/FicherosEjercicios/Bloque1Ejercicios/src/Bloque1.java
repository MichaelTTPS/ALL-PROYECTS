import java.io.File;
public class Bloque1 {
    public static void main(String[] args) throws Exception {
    
// 1. Crea un directorio llamado "dam-accesodatos"
    File directorio= new File("dam-accesodatos");
    if (directorio.mkdir()){ //Crea el directorio
        System.out.println("Creado el directorio "+ directorio);
        } else {
        System.out.println("No se ha podido crear el directorio");
}

System.out.println("-------------------------------");

// 2. Crea un fichero llamado "ejercicio1" dentro del directorio "dam-accesodatos"
    File fichero= new File(directorio, "ejercicio1");
        try {
        if (fichero.createNewFile()){ //Crea el fichero
        System.out.println("Creado el fichero "+ fichero);
        } else {
        System.out.println("No se ha podido crear el fichero");
        }
        } catch (Exception e) {
        System.out.println("Error al crear el fichero: " + e.getMessage());
        }

System.out.println("-------------------------------");

// 3. Muestra por pantalla la longitud del fichero con nombre "ejercicio1"
    System.out.println("Longitud del fichero " + fichero + ": " + fichero.length());

System.out.println("-------------------------------");

// 4. Crea un fichero llamado "ejercicio2" dentro del directorio "dam-accesodatos"
    File fichero2= new File(directorio, "ejercicio2");
        try {
        if (fichero2.createNewFile()){ //Crea el fichero
        System.out.println("Creado el fichero "+ fichero2);
        } else {
        System.out.println("No se ha podido crear el fichero");
        }
        } catch (Exception e) {
        System.out.println("Error al crear el fichero: " + e.getMessage());
        }

System.out.println("-------------------------------");

// 5. Muestra todos los ficheros del directorio "dam-accesodatos"
    String[] ficheros= directorio.list();
        System.out.println("Ficheros en el directorio " + directorio + ":");
        for (String nombreFichero : ficheros) {
        System.out.println(nombreFichero);
        }

System.out.println("-------------------------------");

// 6. Elimina el fichero llamado "ejercicio1"
        if (fichero.delete()) {
        System.out.println("Fichero " + fichero + " eliminado.");
        } else {
        System.out.println("No se ha podido eliminar el fichero " + fichero);
        }

System.out.println("-------------------------------");

// 7. Muestra todos los ficheros del directorio "dam-accesodatos"
    ficheros= directorio.list();
        System.out.println("Ficheros en el directorio " + directorio + " tras eliminar ejercicio1:");
        for (String nombreFichero : ficheros) {
        System.out.println(nombreFichero);
        }

System.out.println("-------------------------------");


// 8. Elimina nuevamente el fichero llamado "ejercicio1"
        if (fichero.delete()) {
        System.out.println("Fichero " + fichero + " eliminado.");
        } else {
        System.out.println("No se ha podido eliminar el fichero " + fichero);
        }

System.out.println("-------------------------------");

// 9. Borrar directorio sin ficheros en su interior
        if (directorio.delete()) {
        System.out.println("Directorio " + directorio + " eliminado.");
        } else {
        System.out.println("No se ha podido eliminar el directorio " + directorio + ". Asegúrate de que está vacío.");
        }

System.out.println("-------------------------------");

// 10. Borrar directorio con ficheros en su interior
    borrarDirectorio(directorio);
    }
    public static void borrarDirectorio(File directorio) {
// Elimina los ficheros contenidos dentro del directorio de forma recursiva
    File[] ficheros = directorio.listFiles();
    if (ficheros != null) {
        for (File fichero : ficheros) {
            if (fichero.isDirectory()) {
                borrarDirectorio(fichero);
            }
            if (fichero.delete()) {
                System.out.println("Fichero " + fichero + " eliminado.");
            } else {
                System.out.println("No se ha podido eliminar el fichero " + fichero);
            }
        }
    }
    if (directorio.delete()) {
        System.out.println("Directorio " + directorio + " eliminado.");
    } else {
        System.out.println("No se ha podido eliminar el directorio " + directorio);
    }
        
}
    
}
