import java.io.File;

public class RutaEjemplo {
    public static void main(String[] args) {
        File archivoAbsoluta = new File("C:\\Users\\micch\\Documents\\Acceso a Datos Ejercicios\\FicherosEjercicios\\reporte.txt");
        System.out.println("Ruta absoluta: " + archivoAbsoluta.getAbsolutePath());

        // Verificar si el archivo existe
        if (archivoAbsoluta.exists()) {
            System.out.println("El archivo existe.\n");
        } else {
            System.out.println("El archivo no existe.\n");
        }

        // Ruta relativa
        File archivoRelativo = new File("./reporte.txt");

        // Verificar si el archivo relativo existe
        if(archivoRelativo.exists()) {
            System.out.println("El archivo relativo existe.\n");
        } else {
            System.out.println("El archivo relativo no existe.\n");
        }

        System.out.println("Ruta relativa convertida: " + archivoRelativo.getAbsolutePath());

        System.out.println("Nombre del archivo: " + archivoAbsoluta.getName());
        System.out.println("Directorio padre: " + archivoAbsoluta.getParent());
        System.out.println("¿Es un directorio? " + archivoAbsoluta.isDirectory());
        System.out.println("¿Es un archivo? " + archivoAbsoluta.isFile());
    }
}