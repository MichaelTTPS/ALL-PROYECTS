import java.io.IOException;
import java.nio.file.*;

public class EscribirFicherosNio {
    public static void main(String[] args) {

        // Listar los archivos en el directorio actual
    Path path = Path.of("ficheroPrueba.txt");

        try {
        Files.writeString(path, "Hola, este es un fichero de prueba.");
        } catch (IOException ex) {
        System.err.println("Error al escribir en el fichero: " + path.getFileName());
        }

        // verificar si se ha escrito
        try {
        String contenido = Files.readString(path);
        System.out.println("\nContenido del fichero: " + contenido);
        } catch (IOException ex) {
        System.err.println("Error al leer el fichero: " + path.getFileName());

        }
    }
}
