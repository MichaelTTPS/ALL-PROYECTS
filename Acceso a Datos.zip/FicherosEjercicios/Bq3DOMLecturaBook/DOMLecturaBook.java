import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class DOMLecturaBook {

    // Clase auxiliar para la ordenación del Punto 3
static class Book {
    String title;
    String author;
    double price;
    String genre;
    String id;

    public Book(String id, String title, String author, double price, String genre) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.price = price;
        this.genre = genre;
    }

    public double getPrice() {
        return price;
    }
}

    public static void main(String[] args){
        List<Book> booksList = new ArrayList<>(); // Necesario para la ordenación (Punto 3)
        
        try {
            File inputFile = new File("books.xml");
            
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

            Document doc = dBuilder.parse(inputFile);

            doc.getDocumentElement().normalize();

            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

            NodeList nList = doc.getElementsByTagName("Book");
            System.out.println("----------------------------");

            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());

    
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;

                    // Extracción de datos
                    String bookId = eElement.getAttribute("id");
                    String author = eElement.getElementsByTagName("Author").item(0).getTextContent();
                    String title = eElement.getElementsByTagName("Title").item(0).getTextContent();
                    double price = Double.parseDouble(eElement.getElementsByTagName("Price").item(0).getTextContent());
                    String genre = eElement.getElementsByTagName("Genre").item(0).getTextContent();

                    // Almacenar para el Punto 3
                    booksList.add(new Book(bookId, title, author, price, genre));

                    System.out.println("\n----------------------------1:");

//1. Muestra por pantalla los diferentes id de cada libro del dichero xml Books.xml utilizando la librería DOM.
                    System.out.println("Book id : " + eElement.getAttribute("id"));

                    System.out.println("\n----------------------------2:");

// 2. Muestra por pantalla una lista de autores y los títulos de sus libros.
                    System.out.println("Author : " + eElement.getElementsByTagName("Author").item(0).getTextContent());
                    System.out.println("Title : " + eElement.getElementsByTagName("Title").item(0).getTextContent());

                    System.out.println("\n----------------------------4:");
// 4. Muestra los libros por su genero
            for (Book book : booksList) {
                System.out.println("4. Título: " + book.title + ", Genero: " + book.genre);
            }
            
                    System.out.println("\n----------------------------3:");

// 3. Muestra por pantalla los títulos de los libros y sus precios. Ordena de más económico a más caro.
            Collections.sort(booksList, Comparator.comparingDouble(Book::getPrice));

            // Muestra por pantalla los títulos y sus precios ordenados.
            for (Book book : booksList) {
                System.out.println("3. Título: " + book.title + ", Precio: " + book.price);
            }

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
