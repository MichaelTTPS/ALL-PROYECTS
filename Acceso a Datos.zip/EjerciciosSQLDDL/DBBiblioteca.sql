CREATE DATABASE Biblioteca;
USE Biblioteca;

CREATE TABLE Libros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100),
    autor VARCHAR(100)
);

INSERT INTO Libros (titulo, autor)
VALUES ('1984', 'George Orwell');

INSERT INTO Libros (titulo, autor)
VALUES ('El Hobbit', 'J.R.R. Tolkien');

