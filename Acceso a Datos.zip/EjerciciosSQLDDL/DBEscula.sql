CREATE DATABASE Escuela;
USE Escuela;
CREATE TABLE Alumnos (
id INT AUTO_INCREMENT PRIMARY KEY,
nombre VARCHAR(100),
edad INT,
email VARCHAR(100)
);
INSERT INTO Alumnos (nombre, edad, email)
VALUES ('Alberto', 20, 'a.fernandez@colegiojosefinos.com');
INSERT INTO Alumnos (nombre, edad, email)
VALUES ('Susana', 19, 's.perez@colegiojosefinos.com');