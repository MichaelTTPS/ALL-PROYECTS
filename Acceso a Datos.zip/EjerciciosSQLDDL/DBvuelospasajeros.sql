-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS vuelospasajeros;
USE vuelospasajeros;
-- Crear tabla de vuelos
CREATE TABLE Vuelos (
cod_vuelo VARCHAR(10) PRIMARY KEY,
destino VARCHAR(50),
fecha DATE
);
-- Crear tabla de pasajeros
CREATE TABLE Pasajeros (
num INT AUTO_INCREMENT PRIMARY KEY,
cod_vuelo VARCHAR(10),
tipo_plaza VARCHAR(20),
fumador BOOLEAN,
FOREIGN KEY (cod_vuelo) REFERENCES Vuelos(cod_vuelo)
);
INSERT INTO Vuelos (cod_vuelo, destino, fecha)
VALUES
('IB100', 'Madrid', '2025-06-01'),
('IB200', 'Barcelona', '2025-06-03');

SELECT * FROM vuelos;