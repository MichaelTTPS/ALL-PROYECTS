CREATE DATABASE banco;
USE banco;
CREATE TABLE cuentas (
id INT AUTO_INCREMENT PRIMARY KEY,
nombre VARCHAR(100) NOT NULL,
saldo DECIMAL(10, 2) NOT NULL
);
INSERT INTO cuentas (nombre, saldo) VALUES ('Cuenta A', 1000.00);
INSERT INTO cuentas (nombre, saldo) VALUES ('Cuenta B', 500.00);

SELECT * FROM cuentas;