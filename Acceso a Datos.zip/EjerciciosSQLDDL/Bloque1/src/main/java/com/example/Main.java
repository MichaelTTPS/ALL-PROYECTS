package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
    // URL de la base de datos, usuario y contraseña
static final String DB_URL = "jdbc:mysql://localhost:3306/dam2"; // Reemplaza 'tu_basedatos'
static final String USER = "root"; // Cambia según tu configuración
static final String PASS = "dddddd*"; // Cambia según tu configuración
    public static void main(String[] args) {
        // Conexión a la base de datos
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
        Statement stmt = conn.createStatement()) {

        // 1.a Crear la tabla Empleado
        String createEmpleado = "CREATE TABLE IF NOT EXISTS Empleado (" +
                "id INT PRIMARY KEY AUTO_INCREMENT," +
                "nombre VARCHAR(20) NOT NULL," +
                "fecha_nacimiento DATE," +
                "genero tinyint(1)," +
                "departamento_id INT," +
                ");";
        stmt.executeUpdate(createEmpleado);
        System.out.println("Tabla Empleado creada o ya existe.");

        // 1.b Crear la tabla Departamento
        String createDepartamento = "CREATE TABLE IF NOT EXISTS Departamento (" +
                                    "id INT PRIMARY KEY AUTO_INCREMENT," + 
                                    "nombre VARCHAR(20) NOT NULL," +
                                    "ubicacion VARCHAR(100)" + 
                                    ");";
        stmt.executeUpdate(createDepartamento);
        System.out.println("Tabla Departamento creada o ya existe.");

        // 2.a. Crear la Foreign Key en la tabla Empleado
        String createForeignKey = "FOREIGN KEY (departamento_id) REFERENCES Departamento(id)";
        /* Restricciones adicionales:
        Si deseas que la eliminación o actualización de un departamento afecte a los empleados asociados,
        puedes agregar las cláusulas ON DELETE o ON UPDATE.
        ON DELETE SET NULL: Si se elimina un departamento, el valor de departamento_id en los empleados relacionados se establece a NULL.
        ON UPDATE CASCADE: Si el valor de id en Departamento cambia, los registros relacionados en Empleado se actualizarán automáticamente.
        */

        stmt.executeUpdate(createForeignKey);
        System.out.println("Foreign Key creada entre Empleado y Departamento.");

        } catch (SQLException e) {
        e.printStackTrace();
        }
    }
}