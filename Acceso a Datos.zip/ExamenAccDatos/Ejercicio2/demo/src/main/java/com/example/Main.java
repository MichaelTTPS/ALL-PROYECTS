package com.example;

import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class Main {

    public static void leerLibrosDesdeXML(String rutaFichero) {

        try {
            File file = new File(rutaFichero);

            // Crear el contexto JAXB y el unmarshaler
            JAXBContext jaxbContext = JAXBContext.newInstance(Biblioteca.class);

            // Unmarshal el archivo XML a objetos Java
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

            // Convertir el XML en un objeto Biblioteca
            Biblioteca biblioteca = (Biblioteca) jaxbUnmarshaller.unmarshal(file);

            // Mostrar los títulos de los libros de género "Ficción"
            System.out.println("Libros de género Ficción:");
            for (Libro libro : biblioteca.getLibro()) {
                if ("Ficción".equalsIgnoreCase(libro.getGenero())) {
                    System.out.println(libro.getTitulo());
                }
            }
        } catch (JAXBException e) {
            System.out.println("Error al leer el archivo XML: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        leerLibrosDesdeXML("libros.xml");
    }
}