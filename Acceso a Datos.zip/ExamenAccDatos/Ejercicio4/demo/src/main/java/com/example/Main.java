package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Main {

    // URL de la base de datos, usuario y contraseña
    static final String DB_URL = "jdbc:mysql://localhost:3306/Biblioteca";
    static final String USER = "root";
    static final String PASS = "1234pepito@"; 

    /*Método en Java que inserte un nuevo libro en la tabla con sus datos y muestre
        por pantalla el número de filas afectadas. */

    public void insertarLibro(String titulo, String autor) {
        String sql = "INSERT INTO Libros (titulo, autor) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, titulo);
            pstmt.setString(2, autor);

            int filasAfectadas = pstmt.executeUpdate();
            System.out.println("Libro insertado correctamente. Filas afectadas: " + filasAfectadas);
        } catch (SQLException e) {
            System.err.println("Error al insertar el libro: " + e.getMessage());
        }
    }

    /*Método en Java que muestre por consola el título y autor de todos los libros
    almacenados. */
        public void mostrarTodosLosLibros() {
            String sql = "SELECT titulo, autor FROM Libros";
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                 PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {

                while (rs.next()) {
                    String titulo = rs.getString("titulo");
                    String autor = rs.getString("autor");
                    System.out.println("Título: " + titulo + ", Autor: " + autor);
                }
            } catch (SQLException e) {
                System.err.println("Error al mostrar los libros: " + e.getMessage());
                
            }
        }
    
        /*Método en Java que actualice el campo autor de un libro dado su id, modifica el
        que quieras para probar el método y muestra por pantalla el número de filas afectadas. */
        public void actualizarAutor(int id, String nuevoAutor) {
            String sql = "UPDATE Libros SET autor = ? WHERE id = ?";
            try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
                PreparedStatement pstmt = conn.prepareStatement(sql)) {

                pstmt.setString(1, nuevoAutor);
                pstmt.setInt(2, id);

                int filasAfectadas = pstmt.executeUpdate();
                System.out.println("Autor actualizado correctamente. Filas afectadas: " + filasAfectadas);
            } catch (SQLException e) {
                System.err.println("Error al actualizar el autor: " + e.getMessage());
            }
        }
        


    public static void main(String[] args) {
        Main app = new Main();

        // Insertar un nuevo libro
        app.insertarLibro("Nada", "Carmen Laforet");

        // Mostrar todos los libros
        app.mostrarTodosLosLibros();

        // Actualizar el autor de un libro con id 1
        app.actualizarAutor(1, "Pepe");
    }
}