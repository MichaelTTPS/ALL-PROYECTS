import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class App {

    public static void guardarContactosEnXML(List<Contacto> contactos) throws Exception {

        // Crear el documento XML
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        // Configurar el factory para que sea seguro
        DocumentBuilder builder = factory.newDocumentBuilder();

        // Crear un nuevo documento
        Document doc = builder.newDocument();

        // Crear el elemento raíz
        Element rootElement = doc.createElement("agenda");
        doc.appendChild(rootElement);

        // Agregar cada contacto al documento
        for (Contacto contacto : contactos) {

            // Crear el elemento persona
            Element personaElement = doc.createElement("persona");

            Element nombreElement = doc.createElement("nombre");
            nombreElement.appendChild(doc.createTextNode(contacto.getNombre()));
            personaElement.appendChild(nombreElement);

            Element emailElement = doc.createElement("email");
            emailElement.appendChild(doc.createTextNode(contacto.getEmail()));
            personaElement.appendChild(emailElement);

            Element telefonoElement = doc.createElement("telefono");
            telefonoElement.appendChild(doc.createTextNode(contacto.getTelefono()));
            personaElement.appendChild(telefonoElement);

            rootElement.appendChild(personaElement);
        }

        // Escribir el contenido en un archivo XML y con sangria usando indentacion
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty("indent", "yes");
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(new File("contactos.xml"));
        transformer.transform(source, result);
    }

    public static void main(String[] args) {
    List<Contacto> contactos = new ArrayList<>();
    contactos.add(new Contacto("Juan Pérez", "juan.perez@email.com", "555-1234"));
    contactos.add(new Contacto("María López", "maria.lopez@email.com", "555-5678"));
    try {
        guardarContactosEnXML(contactos);
        System.out.println("Archivo contactos.xml creado exitosamente.");
    } catch (Exception e) {
        System.out.println("Error al crear el archivo XML.");
        e.printStackTrace();
    }
}

}
