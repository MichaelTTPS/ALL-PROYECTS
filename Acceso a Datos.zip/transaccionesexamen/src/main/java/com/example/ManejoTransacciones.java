package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class ManejoTransacciones {
    // URL de la base de datos, usuario y contraseña
    static final String URL = "jdbc:mysql://localhost:3306/vuelospasajeros";
    static final String USER = "root";
    static final String PASSWORD = "1234pepito@"; 
    
    public static void main(String[] args) {

        manejarTransacciones();
    }

    public static void manejarTransacciones() {
    try (Connection conexion = DriverManager.getConnection(URL, USER, PASSWORD)) {
        // Desactivamos el autocommit
        conexion.setAutoCommit(false);

        try {
            // Sentencias SQL
            String sqlInsert1 = "INSERT INTO Pasajeros (cod_vuelo, tipo_plaza, fumador) VALUES (?, ?, ?)";
            String sqlInsert2 = "INSERT INTO Pasajeros (cod_vuelo, tipo_plaza, fumador) VALUES (?, ?, ?)";

            // Primera operación INSERT
            try (PreparedStatement insert1 = conexion.prepareStatement(sqlInsert1); 
                PreparedStatement insert2 = conexion.prepareStatement(sqlInsert2)) {
                insert1.setString(1, "IB300");
                insert1.setString(2, "Economica");
                insert1.setBoolean(3, false);
                insert1.executeUpdate();

            
                // Condición de prueba para lanzar la excepción
                if (true) {
                    throw new SQLException("Error simulado antes de la segunda operación INSERT.");
                }
             
                insert2.setString(1, "IB400");
                insert2.setString(2, "Primera Clase");
                insert2.setBoolean(3, false);
                insert2.executeUpdate();

                conexion.commit(); // Si todo sale bien, se hace commit
                System.out.println("Transacciones realizadas con éxito.");
            } 

        } catch (SQLException e) {
            // En caso de error, rollback para revertir la transacción
            conexion.rollback();
            System.err.println("Error en las transacciones. Se ha revertido la transacción. " + e.getMessage());
        } finally {
            // Activamos de nuevo el autocommit
             conexion.setAutoCommit(true);
        }

    } catch (SQLException e) {
        System.err.println("Error de conexión a la base de datos." + e.getMessage());
    
    }

}

}
