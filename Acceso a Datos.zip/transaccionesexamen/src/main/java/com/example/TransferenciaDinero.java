package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class TransferenciaDinero {

    // URL de la base de datos, usuario y contraseña
    static final String URL = "jdbc:mysql://localhost:3306/banco";
    static final String USER = "root";
    static final String PASSWORD = "1234pepito@"; 

    public static void main(String[] args) {
        int cuentaOrigen = 1; // ID de Cuenta A
        int cuentaDestino = 2; // ID de Cuenta B
        double cantidad = 200.00; // Cantidad a transferir
        realizarTransferencia(cuentaOrigen, cuentaDestino, cantidad);
    }
    public static void realizarTransferencia(int cuentaOrigen, int cuentaDestino, double cantidad) {
        
        try (Connection conexion = DriverManager.getConnection(URL, USER, PASSWORD)) {
            // Desactivamos el autocommit
            conexion.setAutoCommit(false);

            try {
                // Sentencias SQL
                String sqlRestar = "UPDATE cuentas SET saldo = saldo - ? WHERE id = ?";
                String sqlSumar = "UPDATE cuentas SET saldo = saldo + ? WHERE id = ?";

                // Resta dinero a la cuenta origen
                try (PreparedStatement Restar = conexion.prepareStatement(sqlRestar);
                     PreparedStatement Sumar = conexion.prepareStatement(sqlSumar)) {

                    Restar.setDouble(1, cantidad);
                    Restar.setInt(2, cuentaOrigen);
                    Restar.executeUpdate();

                    Sumar.setDouble(1, cantidad);
                    Sumar.setInt(2, cuentaDestino);
                    Sumar.executeUpdate();
                }
                
                conexion.commit(); // Si todo sale bien, se hace commit
                System.out.println("Transferencia realizada con éxito.");

            } catch (SQLException e) {
                // En caso de error, rollback para revertir la transacción
                conexion.rollback();
                System.err.println("Error en la transferencia. Se ha revertido la transacción.");
            } finally {
                // Activamos de nuevo el autocommit
                 conexion.setAutoCommit(true);
            }

        } catch (SQLException e) {
            System.err.println("Error de conexión a la base de datos.");
     }
     
  }
}